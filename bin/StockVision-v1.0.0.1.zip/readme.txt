==================================================
           StockVision - Control de Inventarios
==================================================

¡Gracias por instalar StockVision!

StockVision es un sistema completo de gestión de inventarios con punto de venta (POS) integrado. Diseñado para facilitar la administración de productos, ventas y existencias, StockVision te ayuda a tomar el control total de tu negocio.

--------------------------------------------
Características principales:
--------------------------------------------
- Control detallado de inventario por producto y categoría
- Gestión de entradas y salidas de mercancía
- Punto de venta fácil de usar y rápido
- Reportes automáticos de ventas, existencias y movimientos
- Soporte para múltiples usuarios con roles y permisos
- Generación de códigos de barras
- Compatible con impresoras de tickets y lectores de código
- Copias de seguridad y restauración de datos

--------------------------------------------
Requisitos del sistema:
--------------------------------------------
- Windows 10 o superior
- .NET Framework 4.8 (o superior)
- 4 GB de RAM (recomendado)
- 500 MB de espacio libre en disco
- Conexión a Internet (solo para actualizaciones)

--------------------------------------------
Instalación:
--------------------------------------------
El programa ya ha sido instalado correctamente en tu equipo.
Puedes iniciar StockVision desde el menú Inicio o desde el acceso directo en el Escritorio.

--------------------------------------------
Soporte técnico:
--------------------------------------------
Si necesitas ayuda o soporte técnico, puedes contactarnos en:

📧 Correo: soporte@stockvision.com  
🌐 Sitio web: www.stockvision.com/soporte  
📞 Teléfono: +52 55 1234 5678

--------------------------------------------
Licencia:
--------------------------------------------
Este software está protegido por leyes de derechos de autor. El uso indebido o la distribución sin autorización están prohibidos.

Versión instalada: 1.0.0  
Fecha de instalación: [DD/MM/AAAA]

Gracias por confiar en StockVision.

El equipo de desarrollo.
